# frozen_string_literal: true

# helping me
module ApplicationHelper
end
