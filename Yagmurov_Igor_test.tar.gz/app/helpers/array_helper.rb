# frozen_string_literal: true

# helping my array controller
module ArrayHelper
end
